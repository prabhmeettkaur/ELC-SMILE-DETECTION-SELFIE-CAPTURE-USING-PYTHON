import random
import cv2
import os
import requests
import numpy as np
from requests.structures import CaseInsensitiveDict
import uuid
# Importing Required Libraries

list_of_quotes = ['Peace begins with a smile',
                  'Smiling is the beauty of the soul',
                  'A smile is a curve that sets everything straight',
                  'Smile, it is the key that fits the lock of everybody\'s heart',
                  'Smiling is free Therapy',
                  'Nothing shakes the smiling heart',
                  'Just for today, smile a little more.',
                  ]

directory_names = ['models', 'capture']  # folders that we need to create
download_files = ['haarcascade_smile.xml', 'haarcascade_frontalface_default.xml']  # haar cascade files that we need to download
base_url = "https://raw.githubusercontent.com/opencv/opencv/master/data/haarcascades/"  # GitHub base URL for haar cascade files
headers = CaseInsensitiveDict()  # Headers for the request

for folder in directory_names:  # create the folders
    if not os.path.exists(folder):
        os.makedirs(folder)

for file in download_files:  # download the files
    if not os.path.exists('models/' + file):
        url = base_url + file
        resp = requests.get(url, headers=headers)
        with open(os.path.join('models', file), 'wb') as f:
            f.write(resp.content)

chosen_quote = random.choice(list_of_quotes)
textsize = cv2.getTextSize(chosen_quote, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)[0]  #Get the size of the text

img = np.zeros((480, 640, 3), dtype="uint8")

textX = int((img.shape[1] - textsize[0]) / 2)  # center the text
textY = int((img.shape[0] + textsize[1]) / 2)

cv2.putText(img, chosen_quote, (textX, textY), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)  # put the quote on the splashscreen
cv2.putText(img, "Made with <3 for ELC", (220, 470), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
cv2.imshow("Smile Detection", img)

cap = cv2.VideoCapture(0)  # capture video from webcam
# load the haar cascade files
face_cascade = cv2.CascadeClassifier('models/haarcascade_frontalface_default.xml')
smile_cascade = cv2.CascadeClassifier('models/haarcascade_smile.xml')

while True:
    success, img = cap.read()
    gray_scale = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    success, img_copy = cap.read()
    faces = face_cascade.detectMultiScale(gray_scale, 1.1, 4)
    cv2.putText(img, "Say Cheese :) [q to Quit]", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2,
                cv2.LINE_AA)
    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 125, 125), 2)
        roi_grayscale = gray_scale[y:y + h, x:x + w]
        roi_color = img[y:y + h, x:x + w]
        smiles_array = smile_cascade.detectMultiScale(roi_grayscale, 1.8, 20)
        for (sx, sy, sw, sh) in smiles_array:
            cv2.putText(img, 'Keep Smiling', (x, y - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36, 255, 12), 2)
            cv2.rectangle(roi_color, (sx, sy), (sx + sw, sy + sh), (255, 0, 255), 2)
            cv2.imwrite(f'capture/img_{uuid.uuid4().hex}.jpg', img_copy)
    cv2.imshow('Smile Detection', img)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
